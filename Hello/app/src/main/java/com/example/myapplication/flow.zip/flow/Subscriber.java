//package com.example.myapplication.flow;
//
//public class Subscriber implements Observer {
//
//    @Override
//    public void onCompleted() {
//
//    }
//
//    @Override
//    public void onError(Throwable t) {
//
//    }
//
//    @Override
//    public int onNext() {
//return
//    }
//}

package com.example.myapplication.flow;

public class SecTask implements Observable.Transformer {
//    @Override
//    public int onNext(int i) {
//        System.out.println("onNext SecTask:"+i);
//        return 2222;
//    }
//
//    @Override
//    public void onCompleted() {
//        System.out.println("onCompleted SecTask");
//    }
//
//    @Override
//    public void onError(Throwable t) {
//        System.out.println("onError SecTask");
//    }

    @Override
    public Object call(Object from) {
        return null;
    }
}
